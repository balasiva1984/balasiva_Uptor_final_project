import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import mean_squared_error

# Load dataset
data = pd.read_csv("cricket_player_data.csv")

# Encoding categorical features
le_opponent = LabelEncoder()
le_venue = LabelEncoder()
data['Opponent_encoded'] = le_opponent.fit_transform(data['Opponent'])
data['Venue_encoded'] = le_venue.fit_transform(data['Venue'])

# Features and Target
X = data[['Opponent_encoded', 'Venue_encoded', 'Previous_Avg', 'Form_Index']]
y = data['Predicted_Runs']

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Model
model = LinearRegression()
model.fit(X_train, y_train)

# Predict
y_pred = model.predict(X_test)

# Evaluation
mse = mean_squared_error(y_test, y_pred)
print(f"Mean Squared Error: {mse:.2f}")

# Predict for a new player match
def predict_player_runs(opponent, venue, prev_avg, form_index):
    opp_encoded = le_opponent.transform([opponent])[0]
    venue_encoded = le_venue.transform([venue])[0]
    input_data = [[opp_encoded, venue_encoded, prev_avg, form_index]]
    predicted_runs = model.predict(input_data)[0]
    return round(predicted_runs, 2)

# Example
predicted = predict_player_runs("Australia", "Mumbai", 42.5, 3)
print(f"Predicted Runs: {predicted}")
